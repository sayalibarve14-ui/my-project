import React from 'react';
import { ShieldCheck, Database, Cpu } from 'lucide-react';

interface FooterProps {
  navigate: (route: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ navigate }) => {
  return (
    <footer className="w-full border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 transition-colors mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="font-bold text-base text-slate-900 dark:text-white">EMOTIX</span>
              <span className="text-xs text-slate-500 font-mono">v1.0.0</span>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-3">
              Multimodal Emotion Intelligence — BSc Computer Science final year academic project.
              Combining Natural Language Processing and Computer Vision for affective computing research.
            </p>
            <div className="flex items-center gap-3 text-xs text-slate-500 font-mono">
              <span className="inline-flex items-center gap-1">
                <Database className="w-3 h-3 text-indigo-500" /> SQLite 3
              </span>
              <span className="inline-flex items-center gap-1">
                <Cpu className="w-3 h-3 text-indigo-500" /> TF-IDF + CV
              </span>
            </div>
          </div>

          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-900 dark:text-white mb-3">
              Project Modules
            </h4>
            <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-400">
              <li>
                <button onClick={() => navigate('text-analysis')} className="hover:text-indigo-600 transition-colors">
                  Natural Language Processing (Text Classifier)
                </button>
              </li>
              <li>
                <button onClick={() => navigate('image-analysis')} className="hover:text-indigo-600 transition-colors">
                  Computer Vision (Facial Expression FER)
                </button>
              </li>
              <li>
                <button onClick={() => navigate('multimodal')} className="hover:text-indigo-600 transition-colors">
                  Multimodal Late Decision Probability Fusion
                </button>
              </li>
              <li>
                <button onClick={() => navigate('docs')} className="hover:text-indigo-600 transition-colors">
                  Technical Architecture & Viva Report
                </button>
              </li>
            </ul>
          </div>

          <div>
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-800 dark:text-slate-200 mb-2">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span>Ethical AI & Privacy Notice</span>
            </div>
            <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
              EMOTIX analyzes provided text and images for educational demonstration.
              Emotion predictions are AI-generated estimates of predicted text emotion and predicted facial expression emotion, and should not be treated as psychological or medical diagnoses.
              No biometric identifiers or personal identities are extracted or stored.
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-100 dark:border-slate-800/80 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 dark:text-slate-500 gap-2">
          <p>© {new Date().getFullYear()} EMOTIX. BSc Computer Science Project. Designed for viva examination.</p>
          <p className="font-mono">Understand emotions. Connect the signals.</p>
        </div>
      </div>
    </footer>
  );
};
